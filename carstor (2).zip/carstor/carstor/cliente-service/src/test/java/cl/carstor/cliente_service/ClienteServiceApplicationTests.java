package cl.carstor.cliente_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClienteServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
