package cl.carstor.cliente_service.dto;

import lombok.Data;

@Data
public class ClienteDTO {
    private  Long id;
    private String nombre;
    private String apellido;
    private Long telefono;
    private String email;
}
