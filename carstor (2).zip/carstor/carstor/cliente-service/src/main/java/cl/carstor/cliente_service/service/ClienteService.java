package cl.carstor.cliente_service.service;

import cl.carstor.cliente_service.dto.ClienteDTO;
import cl.carstor.cliente_service.mapper.ClienteMapper;
import cl.carstor.cliente_service.model.Cliente;
import cl.carstor.cliente_service.repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClienteService {
    @Autowired
    private ClienteRepository clienteRepository;

    @Autowired
    private ClienteMapper clienteMapper;

    public List<Cliente> findall(){
        return clienteRepository.findAll();

    }

    public ClienteDTO findByid(Long id) {
        Cliente cliente = clienteRepository.findById(id).orElse(null);
        return clienteMapper.toDTO(cliente);

    }
    public Cliente save(Cliente cliente){
        return  clienteRepository.save(cliente);

    }

    public void delete (Long id){
        clienteRepository.deleteById(id);

    }
    public Cliente modificar(Long id, Cliente cliente){
        Cliente clienteActualizado = clienteRepository.findById(id).orElse(null);
        if(clienteActualizado == null) return null;
        clienteActualizado.setNombre(cliente.getNombre());
        clienteActualizado.setApellido(cliente.getApellido());
        clienteActualizado.setTelefono(cliente.getTelefono());
        clienteActualizado.setEmail(cliente.getEmail());
        clienteActualizado.setPassword(cliente.getPassword());
        clienteActualizado.setDireccion(cliente.getDireccion());

        return clienteRepository.save(clienteActualizado);


    }




}
