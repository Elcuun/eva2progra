package cl.carstore.empleado_service.repository;

import cl.carstore.empleado_service.model.Empleado;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmpleadoRepository  extends JpaRepository<Empleado, Long> {
}
