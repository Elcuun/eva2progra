package cl.carstore.empleado_service.controller;

import cl.carstore.empleado_service.model.Empleado;
import cl.carstore.empleado_service.service.EmpleadoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/empleados")
public class EmpleadoController {
    @Autowired
    private EmpleadoService empleadoService;

    @GetMapping
    public ResponseEntity<?> listar(){
        return ResponseEntity.ok(empleadoService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(@PathVariable Long id){
        if (empleadoService.findById(id) == null) return  ResponseEntity.notFound().build();
        return ResponseEntity.ok(empleadoService.findById(id));
    }
    @PostMapping
    public ResponseEntity<?> RegistrarEmpleado(@RequestBody Empleado empleado) {
        return new ResponseEntity<>(empleadoService.save(empleado), HttpStatus.CREATED);

    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id){
        empleadoService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
    public  ResponseEntity<?> modificar(@PathVariable Long id, @RequestBody Empleado empleado){
        return ResponseEntity.ok(empleadoService.update(id, empleado));
    }



}
