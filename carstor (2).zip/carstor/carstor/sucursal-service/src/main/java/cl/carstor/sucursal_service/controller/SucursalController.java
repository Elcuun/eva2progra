package cl.carstor.sucursal_service.controller;

import cl.carstor.sucursal_service.model.Sucursal;
import cl.carstor.sucursal_service.service.SucursalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/sucursales")
public class SucursalController {
    @Autowired
    private SucursalService sucursalService;

    @GetMapping
    public ResponseEntity<?> listar(){
        return ResponseEntity.ok(sucursalService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(@PathVariable Long id){
        if (sucursalService.findById(id) == null) return  ResponseEntity.notFound().build();
        return ResponseEntity.ok(sucursalService.findById(id));
    }

    @PostMapping
    public ResponseEntity<?> RegistrarSucursal(@RequestBody Sucursal sucursal) {
        return new ResponseEntity<>(sucursalService.save(sucursal), HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id){
        sucursalService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
    public  ResponseEntity<?> modificar(@PathVariable Long id, @RequestBody Sucursal sucursal){
        return ResponseEntity.ok(sucursalService.update(id, sucursal));
    }

}
