package cl.cartors.envio_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnvioServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
