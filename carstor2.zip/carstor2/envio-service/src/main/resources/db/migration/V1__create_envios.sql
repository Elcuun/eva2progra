CREATE TABLE IF NOT EXISTS envios (
    id_envio BIGINT AUTO_INCREMENT PRIMARY KEY,
    direccion_entrega VARCHAR(150) NOT NULL,
    fecha_envio DATE NOT NULL,
    estado VARCHAR(40) NOT NULL,
    id_pedido BIGINT NOT NULL
);
