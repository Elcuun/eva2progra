package cl.cartors.envio_service.controller;

import cl.cartors.envio_service.model.Envio;
import cl.cartors.envio_service.service.EnvioService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("api/v1/envios")
public class EnvioController {
    @Autowired
    private EnvioService envioService;

    @GetMapping
    public ResponseEntity<?> listar() {
        return ResponseEntity.ok(envioService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(@PathVariable Long id) {
        return ResponseEntity.ok(envioService.findById(id));
    }

    @PostMapping
    public ResponseEntity<?> registrar(@Valid @RequestBody Envio envio) {
        return new ResponseEntity<>(envioService.save(envio), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> modificar(@PathVariable Long id, @Valid @RequestBody Envio envio) {
        return ResponseEntity.ok(envioService.update(id, envio));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id) {
        envioService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/reportes/estado/{estado}")
    public ResponseEntity<?> listarPorEstado(@PathVariable String estado) {
        return ResponseEntity.ok(envioService.findByEstado(estado));
    }

    @GetMapping("/reportes/fechas")
    public ResponseEntity<?> listarPorRangoFechas(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate desde,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate hasta) {
        return ResponseEntity.ok(envioService.findByFechaEnvioBetween(desde, hasta));
    }

    @GetMapping("/reportes/direccion")
    public ResponseEntity<?> listarPorDireccion(@RequestParam String texto) {
        return ResponseEntity.ok(envioService.findByDireccion(texto));
    }

    @GetMapping("/reportes/pedido/{idPedido}")
    public ResponseEntity<?> listarPorPedido(@PathVariable Long idPedido) {
        return ResponseEntity.ok(envioService.findByPedido(idPedido));
    }

    @GetMapping("/reportes/resumen-estado")
    public ResponseEntity<?> resumenPorEstado() {
        return ResponseEntity.ok(envioService.resumenPorEstado());
    }
}
