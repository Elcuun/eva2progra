CREATE TABLE IF NOT EXISTS boletas (
    id_boleta BIGINT AUTO_INCREMENT PRIMARY KEY,
    fecha DATE NOT NULL,
    total DECIMAL(12,2) NOT NULL,
    metodo_pago VARCHAR(40) NOT NULL,
    id_pedido BIGINT NOT NULL
);
