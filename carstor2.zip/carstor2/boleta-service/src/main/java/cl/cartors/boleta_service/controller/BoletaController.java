package cl.cartors.boleta_service.controller;

import cl.cartors.boleta_service.model.Boleta;
import cl.cartors.boleta_service.service.BoletaService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;

@RestController
@RequestMapping("api/v1/boletas")
public class BoletaController {
    @Autowired
    private BoletaService boletaService;

    @GetMapping
    public ResponseEntity<?> listar() {
        return ResponseEntity.ok(boletaService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(@PathVariable Long id) {
        return ResponseEntity.ok(boletaService.findById(id));
    }

    @PostMapping
    public ResponseEntity<?> registrar(@Valid @RequestBody Boleta boleta) {
        return new ResponseEntity<>(boletaService.save(boleta), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> modificar(@PathVariable Long id, @Valid @RequestBody Boleta boleta) {
        return ResponseEntity.ok(boletaService.update(id, boleta));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id) {
        boletaService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/reportes/metodo-pago/{metodoPago}")
    public ResponseEntity<?> listarPorMetodoPago(@PathVariable String metodoPago) {
        return ResponseEntity.ok(boletaService.findByMetodoPago(metodoPago));
    }

    @GetMapping("/reportes/fechas")
    public ResponseEntity<?> listarPorRangoFechas(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate desde,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate hasta) {
        return ResponseEntity.ok(boletaService.findByFechaBetween(desde, hasta));
    }

    @GetMapping("/reportes/total")
    public ResponseEntity<?> listarPorRangoTotal(@RequestParam BigDecimal minimo, @RequestParam BigDecimal maximo) {
        return ResponseEntity.ok(boletaService.findByTotalBetween(minimo, maximo));
    }

    @GetMapping("/reportes/pedido/{idPedido}")
    public ResponseEntity<?> listarPorPedido(@PathVariable Long idPedido) {
        return ResponseEntity.ok(boletaService.findByPedido(idPedido));
    }

    @GetMapping("/reportes/resumen-metodo-pago")
    public ResponseEntity<?> resumenPorMetodoPago() {
        return ResponseEntity.ok(boletaService.resumenPorMetodoPago());
    }

    @GetMapping("/reportes/total-vendido")
    public ResponseEntity<?> totalVendido(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate desde,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate hasta) {
        return ResponseEntity.ok(boletaService.totalVendidoEntreFechas(desde, hasta));
    }
}
