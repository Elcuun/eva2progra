package cl.carstore.empleado_service.repository;

import cl.carstore.empleado_service.model.Empleado;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmpleadoRepository extends JpaRepository<Empleado, Long> {
    Empleado findByEmail(String email);
    List<Empleado> findByCargoContainingIgnoreCase(String cargo);
    List<Empleado> findBySucursal(Long sucursal);
    List<Empleado> findByApellidoContainingIgnoreCase(String apellido);
}
