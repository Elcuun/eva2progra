package cl.cartors.inventario_service.dto;

import lombok.Data;

@Data
public class SucursalDTO {
 private Integer idSucursal;
}
