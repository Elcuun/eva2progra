package cl.cartors.inventario_service.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class InventarioDTO {
    private Integer idInventario;
    private Integer idProducto;
    private Integer idSucursal;
    private Integer stock;
    private LocalDate fechaIngreso;
}
