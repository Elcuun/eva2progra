package cl.cartors.inventario_service.service;

import cl.cartors.inventario_service.Client.ProductoFeign;
import cl.cartors.inventario_service.Client.SucursalFeign;
import cl.cartors.inventario_service.dto.InventarioDTO;
import cl.cartors.inventario_service.dto.ProductoDTO;
import cl.cartors.inventario_service.dto.SucursalDTO;
import cl.cartors.inventario_service.mapper.Inventariomapper;
import cl.cartors.inventario_service.model.Inventario;
import cl.cartors.inventario_service.repository.InventarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InventarioService {
    @Autowired
    InventarioRepository inventarioRepository;
    @Autowired
    SucursalFeign sucursalFeign;
    @Autowired
    ProductoFeign productoFeign;
    @Autowired
    Inventariomapper inventariomapper;

    public List<Inventario> findAll(){
        return inventarioRepository.findAll();

    }
    public InventarioDTO findById(Long id){
        Inventario inventario = inventarioRepository.findById(id).orElse(null);
        InventarioDTO inventarioDTO = inventariomapper.toDTO(inventario);
        SucursalDTO sucursalDTO = sucursalFeign.obtenerSucursal(inventario.getIdSucursal());
        ProductoDTO productoDTO = productoFeign.obtenerProducto(inventario.getIdProducto());
        inventarioDTO.setIdSucursal(sucursalDTO.getIdSucursal());
        return inventarioDTO;

    }
    public Inventario save(Inventario inventario){
        return inventarioRepository.save(inventario);

    }
    public void  delete(Long id){
        inventarioRepository.deleteById(id);

    }
    public Inventario update(Long id, Inventario inventario){
        Inventario inventarioActualizado = inventarioRepository.findById(id).orElse(null);
        if (inventarioActualizado == null ) return null;

        inventarioActualizado.setIdInventario(inventario.getIdInventario());
        inventarioActualizado.setIdSucursal(inventario.getIdSucursal());
        inventarioActualizado.setIdProducto(inventario.getIdProducto());
        inventarioActualizado.setStock(inventario.getStock());
        inventarioActualizado.setFechaIngreso(inventario.getFechaIngreso());
        return inventarioRepository.save(inventarioActualizado);

    }

    public List<Inventario> findByProducto(Integer idProducto) {
        return inventarioRepository.findByIdProducto(idProducto);
    }

    public List<Inventario> findBySucursal(Integer idSucursal) {
        return inventarioRepository.findByIdSucursal(idSucursal);
    }

    public List<Inventario> findByStockBajo(Integer stock) {
        return inventarioRepository.findByStockLessThanEqual(stock);
    }

    public List<Inventario> findByFechaIngreso(java.time.LocalDate desde, java.time.LocalDate hasta) {
        return inventarioRepository.findByFechaIngresoBetween(desde, hasta);
    }

}

