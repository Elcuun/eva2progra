package cl.cartors.inventario_service.Controller;

import cl.cartors.inventario_service.model.Inventario;
import cl.cartors.inventario_service.service.InventarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("api/v1/inventarios")
public class InventaroController {
    @Autowired
    private InventarioService inventarioService;

    @GetMapping
    public ResponseEntity<?> listar() {
        return ResponseEntity.ok(inventarioService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscar(@PathVariable Long id) {
        if (inventarioService.findById(id) == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(inventarioService.findById(id));
    }

    @PostMapping
    public ResponseEntity<?> registrarInventario(@RequestBody Inventario inventario) {
        return new ResponseEntity<>(inventarioService.save(inventario), HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id) {
        inventarioService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> modificar(@RequestBody Inventario inventario, @PathVariable Long id) {
        return ResponseEntity.ok(inventarioService.update(id, inventario));
    }

    @GetMapping("/reportes/producto/{idProducto}")
    public ResponseEntity<?> listarPorProducto(@PathVariable Integer idProducto) {
        return ResponseEntity.ok(inventarioService.findByProducto(idProducto));
    }

    @GetMapping("/reportes/sucursal/{idSucursal}")
    public ResponseEntity<?> listarPorSucursal(@PathVariable Integer idSucursal) {
        return ResponseEntity.ok(inventarioService.findBySucursal(idSucursal));
    }

    @GetMapping("/reportes/stock-bajo/{stock}")
    public ResponseEntity<?> listarPorStockBajo(@PathVariable Integer stock) {
        return ResponseEntity.ok(inventarioService.findByStockBajo(stock));
    }

    @GetMapping("/reportes/fecha-ingreso")
    public ResponseEntity<?> listarPorFechaIngreso(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate desde,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate hasta) {
        return ResponseEntity.ok(inventarioService.findByFechaIngreso(desde, hasta));
    }
}
