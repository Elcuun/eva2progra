package cl.carstore.producto_service.controller;

import cl.carstore.producto_service.model.Producto;
import cl.carstore.producto_service.service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/productos")
public class ProductoController {
    @Autowired
    private ProductoService productoService;

    @GetMapping
    public ResponseEntity<?> listar() {
        return ResponseEntity.ok(productoService.findall());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(@PathVariable Long id) {
        if (productoService.findByid(id) == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(productoService.findByid(id));
    }

    @PostMapping
    public ResponseEntity<?> registrarProducto(@RequestBody Producto producto) {
        return new ResponseEntity<>(productoService.save(producto), HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id) {
        productoService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> modificar(@PathVariable Long id, @RequestBody Producto producto) {
        return ResponseEntity.ok(productoService.modificar(id, producto));
    }

    @GetMapping("/reportes/marca")
    public ResponseEntity<?> listarPorMarca(@RequestParam String marca) {
        return ResponseEntity.ok(productoService.findByMarca(marca));
    }

    @GetMapping("/reportes/estado/{estado}")
    public ResponseEntity<?> listarPorEstado(@PathVariable String estado) {
        return ResponseEntity.ok(productoService.findByEstado(estado));
    }

    @GetMapping("/reportes/precio")
    public ResponseEntity<?> listarPorRangoPrecio(@RequestParam int minimo, @RequestParam int maximo) {
        return ResponseEntity.ok(productoService.findByPrecioBetween(minimo, maximo));
    }

    @GetMapping("/reportes/anio/{anio}")
    public ResponseEntity<?> listarPorAnio(@PathVariable Long anio) {
        return ResponseEntity.ok(productoService.findByAnio(anio));
    }

    @GetMapping("/reportes/color")
    public ResponseEntity<?> listarPorColor(@RequestParam String color) {
        return ResponseEntity.ok(productoService.findByColor(color));
    }
}
