package cl.carstore.producto_service.service;

import cl.carstore.producto_service.dto.ProductoDTO;
import cl.carstore.producto_service.mapper.ProductoMapper;
import cl.carstore.producto_service.model.Producto;
import cl.carstore.producto_service.repository.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductoService {
    @Autowired
    private ProductoRepository productoRepository;
    @Autowired
    private ProductoMapper productoMapper;

    public List<Producto> findall() {
        return productoRepository.findAll();
    }

    public ProductoDTO findByid(Long id) {
        Producto producto = productoRepository.findById(id).orElse(null);
        return productoMapper.toDTO(producto);
    }

    public Producto save(Producto producto) {
        return productoRepository.save(producto);
    }

    public void delete(Long id) {
        productoRepository.deleteById(id);
    }

    public Producto modificar(Long id, Producto producto) {
        Producto productoActualizado = productoRepository.findById(id).orElse(null);
        if (productoActualizado == null) return null;
        productoActualizado.setMarca(producto.getMarca());
        productoActualizado.setModelo(producto.getModelo());
        productoActualizado.setAnio(producto.getAnio());
        productoActualizado.setColor(producto.getColor());
        productoActualizado.setPrecio(producto.getPrecio());
        productoActualizado.setEstado(producto.getEstado());
        return productoRepository.save(productoActualizado);
    }

    public List<Producto> findByMarca(String marca) {
        return productoRepository.findByMarcaContainingIgnoreCase(marca);
    }

    public List<Producto> findByEstado(String estado) {
        return productoRepository.findByEstadoIgnoreCase(estado);
    }

    public List<Producto> findByPrecioBetween(int minimo, int maximo) {
        return productoRepository.findByPrecioBetween(minimo, maximo);
    }

    public List<Producto> findByAnio(Long anio) {
        return productoRepository.findByAnio(anio);
    }

    public List<Producto> findByColor(String color) {
        return productoRepository.findByColorContainingIgnoreCase(color);
    }
}
