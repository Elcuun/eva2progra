package cl.carstore.producto_service.repository;

import cl.carstore.producto_service.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductoRepository extends JpaRepository<Producto, Long> {
    List<Producto> findByMarcaContainingIgnoreCase(String marca);
    List<Producto> findByEstadoIgnoreCase(String estado);
    List<Producto> findByPrecioBetween(int minimo, int maximo);
    List<Producto> findByAnio(Long anio);
    List<Producto> findByColorContainingIgnoreCase(String color);
}
