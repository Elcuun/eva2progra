CREATE DATABASE IF NOT EXISTS bd_clientes;
CREATE DATABASE IF NOT EXISTS bd_empleados;
CREATE DATABASE IF NOT EXISTS bd_sucursales;
CREATE DATABASE IF NOT EXISTS productos;
CREATE DATABASE IF NOT EXISTS bd_inventario;
CREATE DATABASE IF NOT EXISTS bd_pedidos;
CREATE DATABASE IF NOT EXISTS bd_boletas;
CREATE DATABASE IF NOT EXISTS bd_envios;

USE bd_clientes;
CREATE TABLE IF NOT EXISTS cliente (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(80) NOT NULL,
    apellido VARCHAR(80) NOT NULL,
    telefono BIGINT NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    password VARCHAR(120) NOT NULL,
    direccion VARCHAR(150) NOT NULL
);

USE bd_empleados;
CREATE TABLE IF NOT EXISTS empleado (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(80) NOT NULL,
    apellido VARCHAR(80) NOT NULL,
    cargo VARCHAR(80) NOT NULL,
    telefono BIGINT NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    password VARCHAR(120) NOT NULL,
    sucursal BIGINT NOT NULL
);

USE bd_sucursales;
CREATE TABLE IF NOT EXISTS sucursal (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(80) NOT NULL,
    direccion VARCHAR(150) NOT NULL,
    telefono BIGINT NOT NULL
);

USE productos;
CREATE TABLE IF NOT EXISTS producto (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    marca VARCHAR(80) NOT NULL,
    modelo VARCHAR(80) NOT NULL,
    anio BIGINT NOT NULL,
    color VARCHAR(50) NOT NULL,
    precio INT NOT NULL,
    estado VARCHAR(40) NOT NULL
);

USE bd_inventario;
CREATE TABLE IF NOT EXISTS inventario (
    id_inventario INT AUTO_INCREMENT PRIMARY KEY,
    id_producto INT NOT NULL,
    id_sucursal INT NOT NULL,
    stock INT NOT NULL,
    fecha_ingreso DATE NOT NULL
);

USE bd_pedidos;
CREATE TABLE IF NOT EXISTS pedidos (
    idpedido BIGINT AUTO_INCREMENT PRIMARY KEY,
    fechapedido DATE NOT NULL,
    estado VARCHAR(20) NOT NULL,
    id_cliente BIGINT NOT NULL,
    id_empleado BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS detalle_pedido (
    id_detalle BIGINT AUTO_INCREMENT PRIMARY KEY,
    id_pedido BIGINT NOT NULL,
    id_producto BIGINT NOT NULL,
    cantidad INT NOT NULL,
    subtotal DECIMAL(12,2) NOT NULL
);

USE bd_boletas;
CREATE TABLE IF NOT EXISTS boletas (
    id_boleta BIGINT AUTO_INCREMENT PRIMARY KEY,
    fecha DATE NOT NULL,
    total DECIMAL(12,2) NOT NULL,
    metodo_pago VARCHAR(40) NOT NULL,
    id_pedido BIGINT NOT NULL
);

USE bd_envios;
CREATE TABLE IF NOT EXISTS envios (
    id_envio BIGINT AUTO_INCREMENT PRIMARY KEY,
    direccion_entrega VARCHAR(150) NOT NULL,
    fecha_envio DATE NOT NULL,
    estado VARCHAR(40) NOT NULL,
    id_pedido BIGINT NOT NULL
);
