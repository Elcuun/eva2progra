package cl.cartors.pedido_service.Repository;

import cl.cartors.pedido_service.model.Pedido;
import org.springframework.data.jpa.repository.JpaRepository;

import java.sql.Date;
import java.util.List;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {
    List<Pedido> findByEstadoIgnoreCase(String estado);
    List<Pedido> findByIdCliente(Long idCliente);
    List<Pedido> findByIdEmpleado(Long idEmpleado);
    List<Pedido> findByFechapedidoBetween(Date desde, Date hasta);
}
