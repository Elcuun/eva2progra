package cl.cartors.pedido_service.DTO;

import lombok.Data;

import java.sql.Date;
@Data
public class PedidoDTO {
    private Long idpedido;
    private String estado;
    private Date fechapedido;
    private Long idCliente;
    private Long idEmpleado;
    private ClienteDTO cliente;
    private EmpleadoDTO empleado;
}
