package cl.cartors.pedido_service.Controller;

import cl.cartors.pedido_service.Service.PedidoService;
import cl.cartors.pedido_service.model.Pedido;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;

@RestController
@RequestMapping("api/v1/pedidos")
public class PedidoController {
    @Autowired
    private PedidoService pedidoService;

    @GetMapping
    public ResponseEntity<?> listar() {
        return ResponseEntity.ok(pedidoService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(@PathVariable Long id) {
        if (pedidoService.findById(id) == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(pedidoService.findById(id));
    }

    @PostMapping
    public ResponseEntity<?> registrarPedido(@RequestBody Pedido pedido) {
        return new ResponseEntity<>(pedidoService.save(pedido), HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id) {
        pedidoService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> modificar(@PathVariable Long id, @RequestBody Pedido pedido) {
        return ResponseEntity.ok(pedidoService.update(id, pedido));
    }

    @GetMapping("/reportes/estado/{estado}")
    public ResponseEntity<?> listarPorEstado(@PathVariable String estado) {
        return ResponseEntity.ok(pedidoService.findByEstado(estado));
    }

    @GetMapping("/reportes/cliente/{idCliente}")
    public ResponseEntity<?> listarPorCliente(@PathVariable Long idCliente) {
        return ResponseEntity.ok(pedidoService.findByCliente(idCliente));
    }

    @GetMapping("/reportes/empleado/{idEmpleado}")
    public ResponseEntity<?> listarPorEmpleado(@PathVariable Long idEmpleado) {
        return ResponseEntity.ok(pedidoService.findByEmpleado(idEmpleado));
    }

    @GetMapping("/reportes/fechas")
    public ResponseEntity<?> listarPorFechas(@RequestParam Date desde, @RequestParam Date hasta) {
        return ResponseEntity.ok(pedidoService.findByFecha(desde, hasta));
    }
}
