CREATE TABLE IF NOT EXISTS pedidos (
    idpedido BIGINT AUTO_INCREMENT PRIMARY KEY,
    fechapedido DATE NOT NULL,
    estado VARCHAR(20) NOT NULL,
    id_cliente BIGINT NOT NULL,
    id_empleado BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS detalle_pedido (
    id_detalle BIGINT AUTO_INCREMENT PRIMARY KEY,
    id_pedido BIGINT NOT NULL,
    id_producto BIGINT NOT NULL,
    cantidad INT NOT NULL,
    subtotal DECIMAL(12,2) NOT NULL
);
