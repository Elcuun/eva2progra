package cl.carstor.cliente_service.controller;

import cl.carstor.cliente_service.model.Cliente;
import cl.carstor.cliente_service.service.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/clientes")
public class ClienteController {
    @Autowired
    private ClienteService clienteService;

    @GetMapping
    public ResponseEntity<?> listar() {
        return ResponseEntity.ok(clienteService.findall());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(@PathVariable Long id) {
        if (clienteService.findByid(id) == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(clienteService.findByid(id));
    }

    @PostMapping
    public ResponseEntity<?> registrarCliente(@RequestBody Cliente cliente) {
        return new ResponseEntity<>(clienteService.save(cliente), HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id) {
        clienteService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> modificar(@PathVariable Long id, @RequestBody Cliente cliente) {
        return ResponseEntity.ok(clienteService.modificar(id, cliente));
    }

    @GetMapping("/reportes/email/{email}")
    public ResponseEntity<?> buscarPorEmail(@PathVariable String email) {
        return ResponseEntity.ok(clienteService.findByEmail(email));
    }

    @GetMapping("/reportes/apellido")
    public ResponseEntity<?> listarPorApellido(@RequestParam String apellido) {
        return ResponseEntity.ok(clienteService.findByApellido(apellido));
    }

    @GetMapping("/reportes/direccion")
    public ResponseEntity<?> listarPorDireccion(@RequestParam String direccion) {
        return ResponseEntity.ok(clienteService.findByDireccion(direccion));
    }

    @GetMapping("/reportes/nombre")
    public ResponseEntity<?> listarPorNombre(@RequestParam String nombre) {
        return ResponseEntity.ok(clienteService.findByNombre(nombre));
    }
}
