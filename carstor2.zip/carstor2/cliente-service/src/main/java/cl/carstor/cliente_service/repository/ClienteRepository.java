package cl.carstor.cliente_service.repository;

import cl.carstor.cliente_service.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ClienteRepository extends JpaRepository<Cliente, Long> {
    Cliente findByEmail(String email);
    List<Cliente> findByApellidoContainingIgnoreCase(String apellido);
    List<Cliente> findByDireccionContainingIgnoreCase(String direccion);
    List<Cliente> findByNombreContainingIgnoreCase(String nombre);
}
