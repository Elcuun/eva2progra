package cl.carstor.sucursal_service.repository;

import cl.carstor.sucursal_service.model.Sucursal;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SucursalRepository extends JpaRepository<Sucursal, Long> {
    List<Sucursal> findByNombreContainingIgnoreCase(String nombre);
    List<Sucursal> findByDireccionContainingIgnoreCase(String direccion);
    List<Sucursal> findByTelefono(Long telefono);
}
